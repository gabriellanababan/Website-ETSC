/**
 * main.js - Sistem Interaktivitas & Animasi ETSC ITPLN
 */

document.addEventListener('DOMContentLoaded', () => {

  // 1. Hamburger Menu Mobile Navbar Pustral
  const mobileMenuToggle = document.getElementById('mobileMenuToggle');
  const primaryNav = document.getElementById('primaryNav');

  if (mobileMenuToggle && primaryNav) {
    mobileMenuToggle.addEventListener('click', () => {
      mobileMenuToggle.classList.toggle('active');
      primaryNav.classList.toggle('mobile-active');
    });

    primaryNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        if (!link.classList.contains('nav-link-p')) {
          mobileMenuToggle.classList.remove('active');
          primaryNav.classList.remove('mobile-active');
        }
      });
    });
  }

  // 2. Tombol Scroll-to-Top
  const btnBackToTop = document.getElementById('btnBackToTop');
  if (btnBackToTop) {
    const handleScroll = () => {
      const scrollY = window.pageYOffset || document.documentElement.scrollTop || window.scrollY || 0;
      if (scrollY > 200) {
        btnBackToTop.classList.add('show');
      } else {
        btnBackToTop.classList.remove('show');
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    btnBackToTop.addEventListener('click', (e) => {
      e.preventDefault();
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  }

  // 3. Animasi Scroll Reveal
  const revealElements = document.querySelectorAll('.reveal-on-scroll');
  if (revealElements.length > 0) {
    if ('IntersectionObserver' in window) {
      const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      }, {
        threshold: 0.12,
        rootMargin: '0px 0px -40px 0px'
      });

      revealElements.forEach(el => revealObserver.observe(el));
    } else {
      revealElements.forEach(el => el.classList.add('is-visible'));
    }
  }

  // 4. Modal Pencarian & Logika Dummy Search
  const btnSearchOpen = document.getElementById('btnSearchOpen');
  const searchModal = document.getElementById('searchModal');
  const searchCloseBtn = document.getElementById('searchCloseBtn');
  const searchInput = document.getElementById('searchInput'); // Deklarasi cukup 1 kali
  const searchResults = document.getElementById('searchResults');

  if (btnSearchOpen && searchModal && searchCloseBtn) {
    btnSearchOpen.addEventListener('click', () => {
      searchModal.classList.add('show');
      if (searchInput) {
          searchInput.value = ''; // Kosongkan form saat dibuka
          if(searchResults) searchResults.innerHTML = '';
          searchInput.focus();
      }
    });

    searchCloseBtn.addEventListener('click', () => {
      searchModal.classList.remove('show');
    });

    searchModal.addEventListener('click', (e) => {
      if (e.target === searchModal) {
        searchModal.classList.remove('show');
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && searchModal.classList.contains('show')) {
        searchModal.classList.remove('show');
      }
    });
  }

  // Logika Filter Pencarian
  if (searchInput && searchResults) {
    const isRoot = !window.location.pathname.includes('/pages/');
    const basePath = isRoot ? 'pages/' : '';
    const rootPath = isRoot ? '' : '../';

    const searchData = [
      { title: "Beranda Utama", url: rootPath + "index.html", keywords: "beranda home awal depan" },
      { title: "Tentang ETSC", url: basePath + "tentang-etsc.html", keywords: "profil tentang sejarah latar belakang" },
      { title: "Visi dan Misi", url: basePath + "visi-misi.html", keywords: "visi misi tujuan sasaran" },
      { title: "Struktur Organisasi", url: basePath + "struktur-organisasi.html", keywords: "struktur organisasi pengurus ketua" },
      { title: "Tim Pakar", url: basePath + "tim.html", keywords: "tim anggota pakar dewan peneliti" },
      { title: "Bidang Keahlian", url: basePath + "bidang-fokus.html", keywords: "bidang keahlian fokus riset energi" },
      { title: "Mitra & Kerjasama", url: basePath + "mitra.html", keywords: "mitra kerja sama partner" },
      { title: "Agenda Seminar", url: basePath + "seminar.html", keywords: "seminar webinar kegiatan acara forum" },
      { title: "Program Pelatihan", url: basePath + "pelatihan.html", keywords: "pelatihan diklat jadwal program" },
      { title: "Publikasi Jurnal", url: basePath + "jurnal.html", keywords: "jurnal publikasi artikel ilmiah" },
      { title: "Knowledge Base", url: basePath + "knowledge-base.html", keywords: "knowledge base arsip dokumen modul pedoman" }
    ];

    searchInput.addEventListener('input', function() {
      const query = this.value.toLowerCase().trim();
      searchResults.innerHTML = ''; 

      if (query === '') return; 

      const filteredData = searchData.filter(item => 
        item.title.toLowerCase().includes(query) || 
        item.keywords.includes(query)
      );

      if (filteredData.length > 0) {
        filteredData.forEach(item => {
          const resultHTML = `
            <a href="${item.url}" class="search-result-item">
              <div class="search-result-title">${item.title}</div>
              <div class="search-result-url">Buka Halaman <i class="fa-solid fa-arrow-right" style="margin-left:5px;"></i></div>
            </a>
          `;
          searchResults.insertAdjacentHTML('beforeend', resultHTML);
        });
      } else {
        searchResults.innerHTML = `<div class="search-no-result">Oops, tidak ada hasil untuk "<b>${query}</b>"</div>`;
      }
    });
  }

});

// Helper Pencarian Cepat
function quickSearch(keyword) {
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.value = keyword;
    searchInput.focus();
    // trigger event input agar daftar hasil muncul
    const event = new Event('input', { bubbles: true });
    searchInput.dispatchEvent(event);
  }
}